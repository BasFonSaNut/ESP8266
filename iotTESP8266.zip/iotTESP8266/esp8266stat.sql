-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2022 at 08:42 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esp8266stat`
--
CREATE DATABASE IF NOT EXISTS `esp8266stat` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `esp8266stat`;

-- --------------------------------------------------------

--
-- Table structure for table `light`
--

DROP TABLE IF EXISTS `light`;
CREATE TABLE IF NOT EXISTS `light` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `capture_ts` datetime DEFAULT current_timestamp(),
  `capture_dt` date GENERATED ALWAYS AS (cast(`capture_ts` as date)) VIRTUAL,
  `capture_dti` time GENERATED ALWAYS AS (cast(`capture_ts` as time)) VIRTUAL,
  `max_l` smallint(6) NOT NULL DEFAULT 0,
  `min_l` smallint(6) NOT NULL DEFAULT 0,
  `avg_l` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `light`
--

INSERT INTO `light` (`id`, `capture_ts`, `max_l`, `min_l`, `avg_l`) VALUES
(1, '2022-08-18 18:03:00', 0, 1024, 0),
(24, '2022-08-18 18:09:43', 0, 1024, 0);

-- --------------------------------------------------------

--
-- Table structure for table `temper`
--

DROP TABLE IF EXISTS `temper`;
CREATE TABLE IF NOT EXISTS `temper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `capture_ts` datetime DEFAULT current_timestamp(),
  `capture_dt` date GENERATED ALWAYS AS (cast(`capture_ts` as date)) VIRTUAL,
  `capture_dti` time GENERATED ALWAYS AS (cast(`capture_ts` as time)) VIRTUAL,
  `temp` decimal(4,2) NOT NULL DEFAULT 0.00,
  `humid` decimal(4,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `temper`
--

INSERT INTO `temper` (`id`, `capture_ts`, `temp`, `humid`) VALUES
(1, '2022-08-18 18:03:00', '32.10', '78.60');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
