import requests
# pip install requests
'''
code
name
temperature
humidity
'''

url = 'http://192.168.1.52:8000/api_post_sensortemp'
data = {"code": "TM-118","temp":30.50, "humid":50.3}

r = requests.post(url, json = data)
print(r)