-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2022 at 03:20 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esp8266stat`
--

-- --------------------------------------------------------

--
-- Table structure for table `light`
--

CREATE TABLE `light` (
  `id` int(11) NOT NULL,
  `capture_ts` datetime DEFAULT current_timestamp(),
  `capture_dt` date GENERATED ALWAYS AS (cast(`capture_ts` as date)) VIRTUAL,
  `capture_dti` time GENERATED ALWAYS AS (cast(`capture_ts` as time)) VIRTUAL,
  `max_l` smallint(6) NOT NULL DEFAULT 0,
  `min_l` smallint(6) NOT NULL DEFAULT 0,
  `avg_l` smallint(6) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `light`
--

INSERT INTO `light` (`id`, `capture_ts`, `max_l`, `min_l`, `avg_l`) VALUES
(1, '2022-08-18 18:03:00', 0, 1024, 0),
(2, '2022-08-18 18:03:07', 0, 1024, 0),
(3, '2022-08-18 18:03:15', 0, 1024, 0),
(4, '2022-08-18 18:05:04', 0, 1024, 0),
(5, '2022-08-18 18:05:16', 0, 1024, 0),
(6, '2022-08-18 18:05:45', 0, 1024, 0),
(7, '2022-08-18 18:05:52', 0, 1024, 0),
(8, '2022-08-18 18:06:00', 0, 1024, 0),
(9, '2022-08-18 18:07:10', 0, 1024, 0),
(10, '2022-08-18 18:07:16', 0, 1024, 0),
(11, '2022-08-18 18:07:18', 0, 1024, 0),
(12, '2022-08-18 18:07:20', 0, 1024, 0),
(13, '2022-08-18 18:07:22', 0, 1024, 0),
(14, '2022-08-18 18:07:50', 0, 1024, 0),
(15, '2022-08-18 18:07:52', 0, 1024, 0),
(16, '2022-08-18 18:07:53', 0, 1024, 0),
(17, '2022-08-18 18:07:55', 0, 1024, 0),
(18, '2022-08-18 18:07:57', 0, 1024, 0),
(19, '2022-08-18 18:07:59', 0, 1024, 0),
(20, '2022-08-18 18:08:01', 0, 1024, 0),
(21, '2022-08-18 18:08:03', 0, 1024, 0),
(22, '2022-08-18 18:08:05', 0, 1024, 0),
(23, '2022-08-18 18:08:07', 0, 1024, 0),
(24, '2022-08-18 18:09:43', 0, 1024, 0);

-- --------------------------------------------------------

--
-- Table structure for table `temper`
--

CREATE TABLE `temper` (
  `id` int(11) NOT NULL,
  `capture_ts` datetime DEFAULT current_timestamp(),
  `capture_dt` date GENERATED ALWAYS AS (cast(`capture_ts` as date)) VIRTUAL,
  `capture_dti` time GENERATED ALWAYS AS (cast(`capture_ts` as time)) VIRTUAL,
  `temp` decimal(4,2) NOT NULL DEFAULT 0.00,
  `humid` decimal(4,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `temper`
--

INSERT INTO `temper` (`id`, `capture_ts`, `temp`, `humid`) VALUES
(1, '2022-08-18 18:03:00', '32.10', '78.60'),
(2, '2022-08-18 18:03:07', '32.20', '78.30'),
(3, '2022-08-18 18:03:14', '32.20', '78.40'),
(4, '2022-08-18 18:05:04', '32.20', '78.40'),
(5, '2022-08-18 18:05:16', '32.30', '78.10'),
(6, '2022-08-18 18:05:45', '32.30', '78.30'),
(7, '2022-08-18 18:05:52', '32.40', '78.30'),
(8, '2022-08-18 18:05:59', '32.40', '78.30'),
(9, '2022-08-18 18:07:10', '32.40', '78.40'),
(10, '2022-08-18 18:07:16', '32.50', '77.90'),
(11, '2022-08-18 18:07:18', '32.50', '77.90'),
(12, '2022-08-18 18:07:20', '32.50', '78.00'),
(13, '2022-08-18 18:07:22', '32.50', '78.10'),
(14, '2022-08-18 18:07:50', '32.60', '77.90'),
(15, '2022-08-18 18:07:51', '32.50', '77.90'),
(16, '2022-08-18 18:07:53', '32.50', '77.80'),
(17, '2022-08-18 18:07:55', '32.50', '77.70'),
(18, '2022-08-18 18:07:57', '32.60', '77.80'),
(19, '2022-08-18 18:07:59', '32.60', '77.60'),
(20, '2022-08-18 18:08:01', '32.60', '77.80'),
(21, '2022-08-18 18:08:03', '32.50', '77.70'),
(22, '2022-08-18 18:08:05', '32.60', '77.80'),
(23, '2022-08-18 18:08:07', '32.60', '77.70'),
(24, '2022-08-18 18:09:43', '32.60', '77.60');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `light`
--
ALTER TABLE `light`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `temper`
--
ALTER TABLE `temper`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `light`
--
ALTER TABLE `light`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `temper`
--
ALTER TABLE `temper`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
