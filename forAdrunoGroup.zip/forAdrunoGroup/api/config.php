<?php
ob_start();
date_default_timezone_set("Asia/Bangkok");
header ("Last-Modified: " . gmdate ("D, d M Y H:i:s") . " GMT");

function base_url()
{
  return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]"."";
}

function get_client_ip()
{
  $ipaddress = '';
  if (getenv('HTTP_CLIENT_IP'))
    $ipaddress = getenv('HTTP_CLIENT_IP');
  else if(getenv('HTTP_X_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
  else if(getenv('HTTP_X_FORWARDED'))
    $ipaddress = getenv('HTTP_X_FORWARDED');
  else if(getenv('HTTP_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_FORWARDED_FOR');
  else if(getenv('HTTP_FORWARDED'))
    $ipaddress = getenv('HTTP_FORWARDED');
  else if(getenv('REMOTE_ADDR'))
    $ipaddress = getenv('REMOTE_ADDR');
  else
    $ipaddress = 'UNKNOWN';
  return $ipaddress;
}


class DB
{
  public static $str_hosting = 'localhost'; // EDIT
  public static $str_database = 'esp8266stat'; // EDIT
  public static $str_username = 'root'; // EDIT
  public static $str_password = ''; // EDIT

  protected static $pdo = null;
  public static function getConnection()
  {
    // initialize $pdo on first call
    if (self::$pdo == null)
    {
      self::init();
    }

    try
    {
      // echo "Testing connection...\n";
      $old_errlevel = error_reporting(0);
      self::$pdo->query("SELECT 1");
    }
    catch (PDOException $e)
    {
      self::init();
    }
    error_reporting($old_errlevel);
    return self::$pdo;
  }

  protected static function init()
  {
    try
    {
      self::$pdo = new PDO("mysql:host=".self::$str_hosting.";dbname=".self::$str_database, self::$str_username, self::$str_password);
      self::$pdo->exec("set names utf8");
      self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch (PDOException $e)
    {
      die($e->getMessage());
    }
  }
}

function dd_q($str, $arr = [])
{
  $pdo = DB::getConnection();
  try
  {
    $exec = $pdo->prepare($str);
    $exec->execute($arr);
  }
  catch (PDOException $e)
  {
    return false;
  }
  return $exec;
}


$_CONFIG = array();
//title หัวเว็บ
$_CONFIG['title'] = "ESP8266";
//header slide
$_CONFIG['slide'] = "ESP8266";
//footer
$_CONFIG['footer'] = "Copyright © BasFonSaNut.com/ ".date('Y')." All rights reserved.";

//prefix for test
$_CONFIG['prefixfortest'] = "";

?>