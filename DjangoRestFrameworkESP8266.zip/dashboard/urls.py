from django.urls import path
# from dashboard import views
from django.views.generic.base import RedirectView
from django.contrib.staticfiles.storage import staticfiles_storage
from .views import *
urlpatterns = [
    path("", home, name="controller-page"),
    path('api_post_sensortemp',api_post_sensortemp),
    path('api_post_sensorlight',api_post_sensorlight),
    path('api/temp/', TempList.as_view()),
    path('api/light/', LightList.as_view()),
    path("report/", report, name="report-page"),
    path(
        "favicon.ico",
        RedirectView.as_view(url=staticfiles_storage.url("favicon.ico")),
    )
]