try:
  import usocket as socket
except:
  import socket

import json
import network
import time

from machine import Pin, ADC,SoftI2C
from i2c_lcd import I2cLcd
from lcd_api import LcdApi
import dht
import uasyncio

def front_page():
    html_on = """
    <html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no"><link href="http://192.168.1.52/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous"><script src="http://192.168.1.52/jquery.js" crossorigin="anonymous"></script><script src="http://192.168.1.52/esp8266webpage.js" crossorigin="anonymous"></script><link href="http://192.168.1.52/esp8266webpage.css" rel="stylesheet" crossorigin="anonymous"></head><body><center><div class="container"><section><button type="button" class="btn btn-primary reportdatabtn" onclick="linkreport()">DATA</button><button type="button" class="btn btn-secondary reportdatabtn" onclick="linkdashboard()">CONTROLLER</button></section><div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3"><div class="col"><div class="card shadow-sm bd-highlight"><div class="bg-light shadow-sm mx-auto radiuspad"><div class="columns mx-auto center align-items-center"><div class="column"><img id="idimgfan1" src="http://192.168.1.52/media/fanstop.png" width="70%"></div><div class="column"><table cellpadding="5px"><tr><td class="mx-auto center align-items-center" colspan="2"> <img class="bg-light " id="bigfan1" src="http://192.168.1.52/media/bfst.png" width="80px"></td></tr><tr><td><div class="columns"><div class="column onlypad"><img class="" id="statusiconfan1lv1" src="http://192.168.1.52/media/bfw.png" width="35px"><img class="" id="statusiconfan1lv2" src="http://192.168.1.52/media/bfb.png" width="35px"></div></div><div class="columns"><div class="column onlypad"><img class="" id="statusiconfan1lv3" src="http://192.168.1.52/media/bflb.png" width="35px"><img class="" id="statusiconfan1lv4" src="http://192.168.1.52/media/bfr.png" width="35px"></div></div></div></td></tr></table></div></div></div><div class="card-body"><div class="d-flex justify-content-between align-items-center onlypad"><button class="btn btn-primary fanbutton" id="fan1btn1" value="1" type="button" onclick="fmc(1,1)">1</button><button class="btn btn-success fanbutton" id="fan1btn2" value="2" type="button" onclick="fmc(1,2)">2</button><button class="btn btn-warning fanbutton" id="fan1btn3" value="3" type="button" onclick="fmc(1,3)">3</button><button class="btn btn-danger fanbutton" id="fan1btn4" value="4" type="button" onclick="fmc(1,4)">4</button><button class="btn btn-secondary fanbutton" id="fan1btn0" value="0" type="button" onclick="fmc(1,0)">OFF</button></div></div></div></div><div class="col"><div class="card shadow-sm bd-highlight"><div class="bg-light shadow-sm mx-auto radiuspad"><div class="columns mx-auto center align-items-center"><div class="column"><img id="idimgfan2" src="http://192.168.1.52/media/fanstop.png" width="70%"></div><div class="column"><table cellpadding="5px"><tr><td class="mx-auto center align-items-center" colspan="2"><img class="" id="bigfan2" src="http://192.168.1.52/media/bfst.png" width="80px"></td></tr><tr><td><div class="columns"><div class="column onlypad"><img class="" id="statusiconfan2lv1" src="http://192.168.1.52/media/bfw.png" width="35px"><img class="" id="statusiconfan2lv2" src="http://192.168.1.52/media/bfb.png" width="35px"></div></div><div class="columns"><div class="column onlypad"><img class="" id="statusiconfan2lv3" src="http://192.168.1.52/media/bflb.png" width="35px"><img class="" id="statusiconfan2lv4" src="http://192.168.1.52/media/bfr.png" width="35px"></div></div></div></td></tr></table></div></div></div><div class="card-body"><div class="d-flex justify-content-between align-items-center onlypad"><button class="btn btn-primary fanbutton" id="fan2btn1" value="1" type="button" onclick="fmc(2,1)">1</button><button class="btn btn-success fanbutton" id="fan2btn2" value="2" type="button" onclick="fmc(2,2)">2</button><button class="btn btn-warning fanbutton" id="fan2btn3" value="3" type="button" onclick="fmc(2,3)">3</button><button class="btn btn-danger fanbutton" id="fan2btn4" value="4" type="button" onclick="fmc(2,4)">4</button><button class="btn btn-secondary fanbutton" id="fan2btn0" value="0" type="button" onclick="fmc(2,0)">OFF</button></div></div></div></div><div class="col"><div class="card shadow-sm bd-highlight"><div class="bg-light shadow-sm mx-auto radiuspad"><div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 onlyradius"><div class="column"><table cellpadding="5px"><tr><td class="mx-auto center align-items-center" colspan="2"> <img class="" id="bigtemp" src="http://192.168.1.52/media/btst.png" width="80px"></td></tr><tr><td><div class="columns"><div class="column onlypad"><img class="" id="statusicontemplv1" src="http://192.168.1.52/media/btw.png" width="35px"><img class="" id="statusicontemplv2" src="http://192.168.1.52/media/btb.png" width="35px"></div></div><div class="columns"><div class="column onlypad"><img class="" id="statusicontemplv3" src="http://192.168.1.52/media/btlb.png" width="35px"><img class="" id="statusicontemplv4" src="http://192.168.1.52/media/btr.png" width="35px"></div></div></div></td></tr></table></div><div class="column"><table cellpadding="5px"><tr><td class="mx-auto center align-items-center" colspan="2"> <img class="bg-light" id="bighumid" src="http://192.168.1.52/media/bhst.png" width="80px"></td></tr><tr><td><div class="columns"><div class="columns onlypad"><div class="column"><img class="alerts-border " id="statusiconhumidlv1" src="http://192.168.1.52/media/bhw.png" width="35px"><img class="" id="statusiconhumidlv2" src="http://192.168.1.52/media/bhb.png" width="35px"></div></div><div class="columns"><div class="column onlypad"><img class="" id="statusiconhumidlv3" src="http://192.168.1.52/media/bhlb.png" width="35px"><img class="" id="statusiconhumidlv4" src="http://192.168.1.52/media/bhr.png" width="35px"></div></div></div></td></tr></table></div></div></div><div class="card-body"><h3 id="degree">36&deg;</h3></div></div></div><div class="col"><div class="card shadow-sm bd-highlight"><div class="columns"><div class="column"><div class="bg-light shadow-sm mx-auto onlyradius"><img id="idimggreen" src="http://192.168.1.52/media/loff.png" width="50"><h4 id="led1txt" class="text-success">1: OFF</h4><button class="btn btn-success" name="LED" value="ON" type="button" onclick="on_click('green')">ON</button>&nbsp;<button class="btn btn-danger" name="LED" value="OFF" type="button" onclick="off_click('green')">OFF</button></div></div><div class="column"><div class="bg-light shadow-sm mx-auto onlyradius"><img id="idimgred" src="http://192.168.1.52/media/loff.png" width="50"><h4 id="led2txt" class="text-danger">2: OFF</h4><button class="btn btn-success" name="LED" value="ON" type="button" onclick="on_click('red')">ON</button>&nbsp;<button class="btn btn-danger" name="LED" value="OFF" type="button" onclick="off_click('red')">OFF</button></div></div><div class="column"><div class="bg-light shadow-sm mx-auto onlyradius"><img id="idimgyellow" src="http://192.168.1.52/media/loff.png" width="50"><h4 id="led3txt" class="text-warning">3: OFF</h4><button class="btn btn-success" name="LED" value="ON" type="button" onclick="on_click('yellow')">ON</button>&nbsp;<button class="btn btn-danger" name="LED" value="OFF" type="button" onclick="off_click('yellow')">OFF</button></div></div></div><div class="card-body"><div class="align-items-center"><h4 class="font-weight-light">MANUAL LIGHT ON/OFF</4></div></div></div></div><div class="col"><div class="card shadow-sm bd-highlight"><div class="columns"><div class="column"><div class="bg-light shadow-sm mx-auto onlyradius"><img id="imgrelaylight1" src="http://192.168.1.52/media/loff.png" width="50"><h4 id="relaylight1txt" class="text-success">1: OFF</h4></div></div><div class="column"><div class="bg-light shadow-sm mx-auto onlyradius"><img id="imgrelaylight2" src="http://192.168.1.52/media/loff.png" width="50"><h4 id="relaylight2txt" class="text-danger">2: OFF</h4></div></div><div class="column"><div class="bg-light shadow-sm mx-auto onlyradius"><img id="imgrelaylight3" src="http://192.168.1.52/media/loff.png" width="50"><h4 id="relaylight3txt" class="text-warning">3: OFF</h4></div></div></div><div class="d-flex justify-content-between align-items-center"><button class="btn btn-success" name="RELAYON" value="ON" type="button" onclick="rloc()">RELAY ON</button>&nbsp;<button class="btn btn-danger" name="RELAYOFF" value="OFF" type="button" onclick="rlfc()">RELAY OFF</button></div><div class="card-body"><div class="align-items-center onlyradius"><h4 class="font-weight-light">AUTO RELAY ON/OFF BY LIGHT INTENSIVE</h4></div></div></div></div><div class="col"><div class="card shadow-sm bd-highlight mx-auto center"><div class="bg-light shadow-sm mx-auto center g-5 radiuspad"><table class="pad5"><tr><td rowspan="2" width="140px"> <img class="bg-light " id="biglight" src="http://192.168.1.52/media/blst.png" width="110px"></td><td></tr><tr><td><div class="columns"><div class="column pad533"><img class="" id="statusiconlightlv1" src="http://192.168.1.52/media/blw.png" width="50px"><img class="" id="statusiconlightlv2" src="http://192.168.1.52/media/blb.png" width="50px"></div></div><div class="columns"><div class="column pad533"><img class="" id="statusiconlightlv3" src="http://192.168.1.52/media/bllb.png" width="50px"><img class="" id="statusiconlightlv4" src="http://192.168.1.52/media/blr.png" width="50px"></div></div></td></tr></table></div><div class="card-body"><h3 id="idluxtxt">1024 LUX MAX</h3></div></div> </div></div><div class="bg-primary text-white"><h6 class="secondary">THE PROTOTYPE OF LIGHT,TEMPERATURE,HUMID CONTROL AT PLANT HOUSE BY ESP8266.</h6><h5 class="secondary"> BAS,FON,SA,NUT GRADE 4th.</h5></div></center></body></html>
"""
    return html_on
    
def htmlheader(connx):
    header = """HTTP/1.0 200 OK
    Content-Type: text/html; charset=utf-8
    Access-Control-Allow-Origin: *

"""
    connx.send(header)

def jsonheader(connx):
    header = """HTTP/1.0 200 OK
    Content-Type: application/json; charset=utf-8
    Access-Control-Allow-Origin: *

"""
    connx.send(header)
    
def jsonresponse(jsondata):
    return json.dumps(jsondata)

def get_temp_humid():
    d.measure()
    time.sleep(1)
    temp = d.temperature()
    humid = d.humidity()
    text = 'TEMP: {:.1f} C , HUMID: {:.1f} %'.format(temp,humid)
    print(text)
    return (temp, humid)

def runrelay():
    relay_on()
    time.sleep(3)
    relay_off()
    time.sleep(3)
    relay_on()
    time.sleep(3)
    relay_off()
    
def relay_on():
    relay.value(0)
    print('LED:ON')

def relay_off():
    relay.value(1)
    print('LED:OFF')
    
def luxcurrent():
    LDR_value = LDR.read()
    print('LUX: {} '.format(LDR_value))
    
    return LDR_value

ssid = "Saitip_2.4GHz"
password = "Saitip0937211746"
station = network.WLAN(network.STA_IF)

station.active(True)
station.connect(ssid, password)

while station.isconnected() == False:
  pass

print('Connection successful')
print(station.ifconfig())

ledgreen = Pin(0, Pin.OUT)
ledgreen.off()

ledred = Pin(12, Pin.OUT)
ledred.off()

ledyellow = Pin(2, Pin.OUT)
ledyellow.off()


i2c = SoftI2C(scl=Pin(5),sda=Pin(4),freq=100000)
print('===LCD SCAN==: ',hex(i2c.scan()[0]))
lcd = I2cLcd(i2c, 0x27, 2, 16)

time.sleep(1)
lcd.clear() 

text = 'LCD STAND BY...'
lcd.putstr(text)
degree = bytearray([0x10,  0x0E,  0x11,  0x10,  0x10,  0x11,  0x0E,  0x00])
lcd.custom_char(0,degree)

d = dht.DHT22(Pin(14))
relay = Pin(15,Pin.OUT)

LDR = ADC(0)
ldrled = Pin(16,Pin.OUT)
ldrled.off()

def runserver():
    addr = socket.getaddrinfo('0.0.0.0', 89)[0][-1]
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(addr)
    s.listen(5)
   
    while True:
      conn, addr = s.accept()
      print('Got a connection from %s' % str(addr))
      
      print("==============================================")
      request = conn.recv(1024).decode('utf-8')
      request = str(request)
      print(request)
      print('Content = %s' % request)
      print("==============================================")
      if 'favicon' in str(request):
        continue 
      elif 'LED1=ON' in str(request):
        print('LED1 : ON')
        ledgreen.value(1)
        lcd.clear()
        lcd.putstr('{}'.format('LED1 : ON'))
        resback = {'LED':'LED1','STATUS':'ON'}
        jsonheader(conn)
        conn.sendall(jsonresponse(resback))
        
      elif 'LED1=OFF' in str(request):
        print('LED1 : OFF')
        ledgreen.value(0)
        lcd.clear()
        lcd.putstr('{}'.format('LED1 : OFF'))
        resback = {'LED':'LED1','STATUS':'OFF'}
        jsonheader(conn)
        conn.sendall(jsonresponse(resback))
      elif 'LED2=ON' in str(request):
        print('LED2 : ON')
        ledred.value(1)
        lcd.clear()
        lcd.putstr('{}'.format('LED2 : ON'))
        resback = {'LED':'LED2','STATUS':'ON'}
        jsonheader(conn)
        conn.sendall(jsonresponse(resback))
      elif 'LED2=OFF' in str(request):
        print('LED2 : OFF')
        ledred.value(0)
        lcd.clear()
        lcd.putstr('{}'.format('LED2 : OFF'))
        resback = {'LED':'LED2','STATUS':'OFF'}
        jsonheader(conn)
        conn.sendall(jsonresponse(resback))
      elif 'LED3=ON' in str(request):
        print('LED3 : ON')
        ledyellow.value(1)
        lcd.clear()
        lcd.putstr('{}'.format('LED3 : ON'))
        resback = {'LED':'LED3','STATUS':'ON'}
        jsonheader(conn)
        conn.sendall(jsonresponse(resback))
      elif 'LED3=OFF' in str(request):
        print('LED3 : OFF')
        ledyellow.value(0)
        lcd.clear()
        lcd.putstr('{}'.format('LED3 : OFF'))
        resback = {'LED':'LED3','STATUS':'OFF'}
        jsonheader(conn)
        conn.sendall(jsonresponse(resback))
      elif 'RELAY=ON' in str(request):
        print('RELAY : ON')
        relay_on()
        ldrled.on()
        lcd.clear()
        lcd.putstr('RELAY : ON')
        resback = {'RELAY':'ON'}
        jsonheader(conn)
        conn.sendall(jsonresponse(resback))
      elif 'RELAY=OFF' in str(request):
        print('RELAY : OFF')
        relay_off()
        ldrled.off()
        lcd.clear()
        lcd.putstr('RELAY : OFF')
        resback = {'RELAY':'OFF'}
        jsonheader(conn)
        conn.sendall(jsonresponse(resback))  
      elif 'GETTEMPLIGHT' in str(request):
        t,h = get_temp_humid()
        resbackt = {'TEMP':t ,'HUMID':h}
        minX = luxcurrent()
        resbackl = {'MIN':minX}
        print('TEMP: {},HUMID: {}'.format(t,h))
        print('Light : {}'.format(minX))
        if minX > 800 :
            print('RELAY : ON')
            relay_on()
            lcd.clear()
            lcd.putstr('RELAY : ON')
        else:
            print('RELAY : OFF')
            relay_off()
            lcd.clear()
            lcd.putstr('RELAY : OFF')
        
        resback = {'TEMP':resbackt,'LUX':resbackl}
        jsonheader(conn)
        conn.sendall(jsonresponse(resback))
      else:
        htmlheader(conn)
        conn.sendall(front_page()) 
      
      conn.close()

runserver()