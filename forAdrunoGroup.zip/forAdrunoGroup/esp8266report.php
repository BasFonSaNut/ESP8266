<?php
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: *');
header('Access-Control-Allow-Headers: *');
$df = date("Y/m/d");
$a  = date_create(date("Y/m/d"));
$cd = date_format($a,'d-m-Y');
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no">
	<!-- เปลี่ยน ip เป็นเครื่องตัวเอง -->
	<script src="http://192.168.1.52/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
	<script src="http://192.168.1.52/jquery.js"  crossorigin="anonymous"></script>
    <link href="http://192.168.1.52/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="http://192.168.1.52/esp8266webpage.js" crossorigin="anonymous"></script>
   	<link href="http://192.168.1.52/esp8266webpage.css" rel="stylesheet" crossorigin="anonymous">
   	<script src="http://192.168.1.52/plugins/datatables/jquery.dataTables.js"></script>
    <script src="http://192.168.1.52/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
  </head>
 
	<body>
		<center>
			<div class="container">
			<div class="section">
				  <div style="width: 100%px; border-radius: 21px 21px 0 0; "> 
						  <button type="button" class="btn btn-primary" onclick="linkreport()" style="width: 200px; height: 45px; border-radius: 21px 21px 0 0; ">DATA</button>
						 <button type="button" class="btn btn-secondary"  onclick="linkdashboard()" style="width: 200px; height: 45px; border-radius: 21px 21px 0 0; ">CONTROLLER</button>
				  </div>
			</section>

				<div class="row">
					<div class="col-sm-6">
						<div class="card">
							<div class="card-body">
								<h5 class="card-title">AVERAGE LIGHT TODAY</h5>
								<div class="columns">
									<div class="column" style="padding-right:30px">
										<div class="bg-light shadow-sm mx-auto" style="width: 100%; height: 100px; border-radius: 21px 21px 0 0;">
											<h3 id="relaylight3txt" class="text-primary">39.1</h3>
											<h4 id="relaylight2txt"  class="text-primary">MIN</h4>
										</div>
									</div>

									<div class="column" style="padding-right:30px">
										<div class="bg-light shadow-sm mx-auto" style="width: 100%; height: 100px; border-radius: 21px 21px 0 0;">
											<h3 id="relaylight3txt" class="text-danger">61.9</h3>
											<h4 id="relaylight3txt" class="text-danger">MAX</h4>
										</div>
									</div><!--ENDCOLUMN-->

									<div class="column">
										<div class="bg-light shadow-sm mx-auto" style="width: 100%; height: 100px; border-radius: 21px 21px 0 0;">
											<h3 id="relaylight3txt" class="text-success">61.9</h3>
											<h4 id="relaylight3txt" class="text-success">AVG</h4>
										</div>
									</div><!--ENDCOLUMN-->
								</div><!--ENDCOLUMNS-->

								<div class="accordion" id="report1">
									<div class="accordion-item">
										<h2 class="accordion-header" id="report1-1">
										<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#report11" aria-expanded="true" aria-controls="collapseOne">
											SEARCH
										</button>
										</h2>

										<div id="report11" class="accordion-collapse collapse" aria-labelledby="report1-1" data-bs-parent="#report1">
											<div class="accordion-body">
												<div class="flex-gap">
													<div>
														<div class="input-group">
															<span class="input-group-text">FROM</span>
															<input type="date" value="" id="dfl" name="dfl">
														</div> 
													</div>

													<div>
														<div class="input-group">
															<span class="input-group-text">TO</span>
															<input type="date" value="" id="dtl" name="dtl">
														</div>
													</div>

													<div>
														<button class="btn btn-success" id="btnlight_search">SEARCH</button>
													</div>
													<div id="notice_searchlight"></div>
												</div><!--END FLEX-->
											</div><!-- END ITEM 1-1 accordion-body-->
										</div><!--END accordion-collapse ITEM 1-1-->
									</div><!--END accordion-item 1-1-->

									<div class="accordion-item">
										<h2 class="accordion-header" id="report1-2">
										<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#report12" aria-expanded="false" aria-controls="collapseTwo">
											RESULT
										</button>
										</h2>
										<div id="report12" class="accordion-collapse collapse" aria-labelledby="report1-2" data-bs-parent="#report1">
											<div class="accordion-body">
												<section class="content">
													<div class="row">
														<div class="col-sm-12">
															<div class="card card-outline">
																<div class="card-body box-profile">
																	<div class="table-responsive">
																		<table class="table" id="tb_datalight" style="width: 100%;">
																			<thead class="text-center">
																				<tr>
																					<th scope="col">DATE</th>
																					<th scope="col">TIME</th>
																					<th scope="col">MIN</th>
																					<th scope="col">MAX</th>
																					<th scope="col">AVG</th>
																				</tr>
																			</thead>
																		</table>
																	</div>
																</div>
															</div>
														</div>
													</div><!--END ROW-->
												</section>
											</div><!-- END ITEM 1-2 accordion-body-->
										</div><!--END accordion-collapse ITEM 1-2-->
									</div><!--END accordion-item 1-2-->

									<div class="accordion-item">
										<h2 class="accordion-header" id="report1-3">
										<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#report13" aria-expanded="false" aria-controls="collapseThree">
											REPORT MANUAL
										</button>
										</h2>
										<div id="report13" class="accordion-collapse collapse" aria-labelledby="report1-3" data-bs-parent="#report1">
											<div class="accordion-body" style="text-align: left;">
												<strong>คู่มือการใช้ รีพอร์ต</strong> <br/>
												1. เมื่อเข้ามาแสดงผลข้อมูลวันปัจจุบัน<br/>
												2. หากต้องการค้นหาข้อมูลที่ต้องการ กด SEARCH เพื่อกางส่วนค้นหา (วิ่งไปเอาข้อมูลจาก server side)<br/>
												3. เมื่อกดปุ่มค้นหา ผลการค้นจะแสดงที่ ส่วนของ RESULT <br/>
												4. การค้นหาในส่วนของแสดงผล เป็นการค้นหาจาก จาก set ของ data ที่ได้มาจาก การกดค้นใน step 2 <br/>
												5. เข้ามาครั้งแรกแสดงค่าเรคคอร์ดที่บันทึกในวันปัจจุบัน<br/>
												6. การค้นหาหาก ใส่แค่ค่าจากวันที่ อย่างเดียว ค้นหา ค้นจากวันที่เลือกมาจนถึงวันปัจจุบัน<br/>
												7. การค้นหาหาก ใส่แค่ค่าถึงวันที่ อย่างเดียว ค้นหา ค้นจากวันที่เลือกมาจน ย้อนหลัง ไปจนถึงเรคคอร์ดแรกที่บันทึกไว้<br/>
												8. การค้นหาหาก ใส่แค่ค่า ทั้งสอง ค้นหาเรคคอร์ดที่บันทึกไว้ ตกในช่วงวันดังกล่าว<br/>
												9. การค้นหาหาก ไม่ใส่ค่าใดๆ เลย แสดงค่าเรคคอร์ดที่บันทึกในวันปัจจุบัน
											</div><!--END accordion report1-item3 body-->
										</div><!--END accordion report1-item3 collapse-->
									</div><!--END accordion report1-item3-->
								</div><!--END accordion report1-->
							</div><!--END CARD BODY1-->
						</div><!--END CARD 1-->
					</div><!--END COL-->
				
						
					<div class="col-sm-6">
						<div class="card">
							<div class="card-body">
								<h5 class="card-title">AVERAGE TEMP : HUMID TODAY</h5>
								<div class="columns">
									<div class="column" style="padding-right:30px">
										<div class="bg-light shadow-sm mx-auto" style="width: 100%; height: 100px; border-radius: 21px 21px 0 0;">
											<h3 id="relaylight3txt" class="text-danger">39.1</h3>
											<h4 id="relaylight2txt"  class="text-danger">TEMP</h4>
										</div>
									</div>
								
									<div class="column">
										<div class="bg-light shadow-sm mx-auto" style="width: 100%; height: 100px; border-radius: 21px 21px 0 0;">
											<h3 id="relaylight3txt" class="text-primary">61.9</h3>
											<h4 id="relaylight3txt" class="text-primary">HUMID</h4>
										</div>
									</div><!--ENDCOLUMN-->
								</div><!--END COLUMNS-->
								


								<div class="accordion" id="report2">
									<div class="accordion-item">
										<h2 class="accordion-header" id="report2-1">
										<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#report21" aria-expanded="true" aria-controls="collapseOne">
											SEARCH
										</button>
										</h2>

										<div id="report21" class="accordion-collapse collapse" aria-labelledby="report2-1" data-bs-parent="#report2">
											<div class="accordion-body">
												<div class="flex-gap">
													<div>
														<div class="input-group">
															<span class="input-group-text">FROM</span>
															<input type="date" id="dft" value="" name="dft">
														</div> 
													</div>

													<div>
														<div class="input-group">
															<span class="input-group-text">TO</span>
															<input type="date" id="dtt" value="" name="dtt">
														</div>
													</div>

													<div>
														<button class="btn btn-success" id="btntemp_search">SEARCH</button>
													</div>
													<div id="notice_searchtmp"></div>						
												</div><!--END FLEX -->
											</div><!--END accordion body  item 2-1-->
										</div><!--END accordion colappse item 2-1-->
									</div><!--END accordion item 2-1-->


									<div class="accordion-item">
										<h2 class="accordion-header" id="report2-2">
										<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#report22" aria-expanded="false" aria-controls="collapseTwo">
											RESULT
										</button>
										</h2>
										<div id="report22" class="accordion-collapse collapse" aria-labelledby="report2-2" data-bs-parent="#report2">
											<div class="accordion-body">
												<section class="content">
													<div class="row">
														<div class="col-sm-12">
															<div class="card card-outline">
																<div class="card-body box-profile">
																	<div class="table-responsive">
																		<table class="table" id="tb_datatemp" style="width: 100%;">
																			<thead class="text-center">
																				<tr>
																					<th scope="col">DATE</th>
																					<th scope="col">TIME</th>
																					<th scope="col">TEMP</th>
																					<th scope="col">HUMID</th>
																				</tr>
																			</thead>
																		</table>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</section>
											</div>
										</div>
									</div><!--END accordion-item 2-->

									<div class="accordion-item">
										<h2 class="accordion-header" id="report2-3">
										<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#report23" aria-expanded="false" aria-controls="collapseThree">
											REPORT MANUAL
										</button>
										</h2>
										<div id="report23" class="accordion-collapse collapse" aria-labelledby="report2-3" data-bs-parent="#report2">
											<div class="accordion-body"  style="text-align: left;">
												<strong>คู่มือการใช้ รีพอร์ต</strong> <br/>
													1. เมื่อเข้ามาแสดงผลข้อมูลวันปัจจุบัน<br/>
													2. หากต้องการค้นหาข้อมูลที่ต้องการ กด SEARCH เพื่อกางส่วนค้นหา (วิ่งไปเอาข้อมูลจาก server side)<br/>
													3. เมื่อกดปุ่มค้นหา ผลการค้นจะแสดงที่ ส่วนของ RESULT <br/>
													4. การค้นหาในส่วนของแสดงผล เป็นการค้นหาจาก จาก set ของ data ที่ได้มาจาก การกดค้นใน step 2 <br/>
													5. เข้ามาครั้งแรกแสดงค่าเรคคอร์ดที่บันทึกในวันปัจจุบัน<br/>
													6. การค้นหาหาก ใส่แค่ค่าจากวันที่ อย่างเดียว ค้นหา ค้นจากวันที่เลือกมาจนถึงวันปัจจุบัน<br/>
													7. การค้นหาหาก ใส่แค่ค่าถึงวันที่ อย่างเดียว ค้นหา ค้นจากวันที่เลือกมาจน ย้อนหลัง ไปจนถึงเรคคอร์ดแรกที่บันทึกไว้<br/>
													8. การค้นหาหาก ใส่แค่ค่า ทั้งสอง ค้นหาเรคคอร์ดที่บันทึกไว้ ตกในช่วงวันดังกล่าว<br/>
													9. การค้นหาหาก ไม่ใส่ค่าใดๆ เลย แสดงค่าเรคคอร์ดที่บันทึกในวันปัจจุบัน
													
											</div>
										</div>
									</div><!--END accordion-item 3-->
								</div><!--END CORDIAN REPORT2-->
							</div><!--END CARD BODY-->
						</div><!--END CARD-->
					</div><!--END COL-->
				</div><!--END ROW-->	
			</div><!--END CONTAINER-->
		</center>
	</body>
</html>

<script>
 $( document ).ready(function() 
 {
	$(function () 
	{
		$('#tb_datalight').DataTable({
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": false,
			"info": true,
			"autoWidth": false,
			"lengthMenu": [[5, 10,25, 50, 100, -1], [5,10, 25, 50, 100, "ทั้งหมด"]],
			"language": {
				"emptyTable":     "ไม่พบข้อมูล",
				"info":           "แสดงข้อมูลแถวที่ _START_ ถึง _END_ จากทั้งหมด _TOTAL_ แถว",
				"infoEmpty":      "ไม่พบข้อมูล",
				"infoFiltered":   "(ค้นหาจากข้อมูลทั้งหมด _MAX_ แถว)",
				"infoPostFix":    "",
				"thousands":      ",",
				"lengthMenu":     "การแสดงผล _MENU_ แถว",
				"search":         "ค้นหา:",
				"zeroRecords":    "ไม่พบข้อมูลที่ค้นหา",
				"paginate": {
					"first":      "หน้าแรก",
					"last":       "หน้าสุดท้าย",
					"next":       "ถัดไป",
					"previous":   "ก่อนหน้า"
				}
			},
			"processing": true,
			"serverSide": true,
			"ajax": "./datatable/light.php?dfl=<?=$df?>"
		});
	});


	$(function () {
		$('#tb_datatemp').DataTable({
		"paging": true,
		"lengthChange": true,
		"searching": true,
		"ordering": false,
		"info": true,
		"autoWidth": false,
		"lengthMenu": [[5, 10,25, 50, 100, -1], [5,10, 25, 50, 100, "ทั้งหมด"]],
		"language": {
			"emptyTable":     "ไม่พบข้อมูล",
			"info":           "แสดงข้อมูลแถวที่ _START_ ถึง _END_ จากทั้งหมด _TOTAL_ แถว",
			"infoEmpty":      "ไม่พบข้อมูล",
			"infoFiltered":   "(ค้นหาจากข้อมูลทั้งหมด _MAX_ แถว)",
			"infoPostFix":    "",
			"thousands":      ",",
			"lengthMenu":     "การแสดงผล _MENU_ แถว",
			"search":         "ค้นหา:",
			"zeroRecords":    "ไม่พบข้อมูลที่ค้นหา",
			"paginate": {
				"first":      "หน้าแรก",
				"last":       "หน้าสุดท้าย",
				"next":       "ถัดไป",
				"previous":   "ก่อนหน้า"
			}
		},
		"processing": true,
		"serverSide": true,
		"ajax": "./datatable/temper.php?dft=<?=$df?>"
		
		});
	});	
});	


$("#btnlight_search").click(function(e) {
	var table = $('#tb_datalight').DataTable();
    table.destroy();
	$('#notice_searchlight').html('<div><img src="pleasewait2.gif" width="60%"></div>');
	
	var dfl = $("#dfl").val()
	var dtl = $("#dtl").val()
	
    $(function () {
		$('#tb_datalight').DataTable({
		"paging": true,
		"lengthChange": true,
		"searching": true,
		"ordering": false,
		"info": true,
		"autoWidth": false,
		"lengthMenu": [[5, 10,25, 50, 100, -1], [5,10, 25, 50, 100, "ทั้งหมด"]],
		"language": {
			"emptyTable":     "ไม่พบข้อมูล",
			"info":           "แสดงข้อมูลแถวที่ _START_ ถึง _END_ จากทั้งหมด _TOTAL_ แถว",
			"infoEmpty":      "ไม่พบข้อมูล",
			"infoFiltered":   "(ค้นหาจากข้อมูลทั้งหมด _MAX_ แถว)",
			"infoPostFix":    "",
			"thousands":      ",",
			"lengthMenu":     "การแสดงผล _MENU_ แถว",
			"search":         "ค้นหา:",
			"zeroRecords":    "ไม่พบข้อมูลที่ค้นหา",
			"paginate": {
				"first":      "หน้าแรก",
				"last":       "หน้าสุดท้าย",
				"next":       "ถัดไป",
				"previous":   "ก่อนหน้า"
			}
		},
		"processing": true,
		"serverSide": true,
		"ajax": "./datatable/light.php?dfl="+dfl+"&dtl="+dtl
		});
	});
	$('#notice_searchlight').html('<div><span class="searchinfo">SEARCH COMPLETE</span></div>');
});


$("#btntemp_search").click(function(e) {
	var table = $('#tb_datatemp').DataTable();
    table.destroy();
	$('#notice_searchtmp').html('<div><img src="pleasewait2.gif" width="60%"></div>');
	var dft = $("#dft").val()
	var dtt = $("#dtt").val()
    $(function () {
		$('#tb_datatemp').DataTable({
		"paging": true,
		"lengthChange": true,
		"searching": true,
		"ordering": false,
		"info": true,
		"autoWidth": false,
		"lengthMenu": [[5, 10,25, 50, 100, -1], [5,10, 25, 50, 100, "ทั้งหมด"]],
		"language": {
			"emptyTable":     "ไม่พบข้อมูล",
			"info":           "แสดงข้อมูลแถวที่ _START_ ถึง _END_ จากทั้งหมด _TOTAL_ แถว",
			"infoEmpty":      "ไม่พบข้อมูล",
			"infoFiltered":   "(ค้นหาจากข้อมูลทั้งหมด _MAX_ แถว)",
			"infoPostFix":    "",
			"thousands":      ",",
			"lengthMenu":     "การแสดงผล _MENU_ แถว",
			"search":         "ค้นหา:",
			"zeroRecords":    "ไม่พบข้อมูลที่ค้นหา",
			"paginate": {
				"first":      "หน้าแรก",
				"last":       "หน้าสุดท้าย",
				"next":       "ถัดไป",
				"previous":   "ก่อนหน้า"
			}
		},
		"processing": true,
		"serverSide": true,
		"ajax": "./datatable/temper.php?dft="+dft+"&dtt="+dtt
		});
	});
	$('#notice_searchtmp').html('<div><span class="searchinfo">SEARCH COMPLETE</span></div>');
	
	$( ".selector" ).accordion({ active: 2 });
});

</script>  