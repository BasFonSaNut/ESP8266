from django.shortcuts import render
# Create your views here.
from django.http import HttpResponse

#########API LIBRARY ############
from django.http import JsonResponse
from rest_framework.parsers import JSONParser
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .serializers import *
from rest_framework import generics
import json


class TempList(generics.ListAPIView):
    serializer_class = TempSerializer
    paginate_by = 1
    queryset = Temp.objects.all()
    
    def post(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

class LightList(generics.ListAPIView):
    serializer_class = LightSerializer
    paginate_by = 5
    queryset = Light.objects.all()
    
    def post(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)
    
@api_view(['POST',])
def api_post_sensortemp(request):

	if request.method == 'POST':
		try:
			serializer = TempSerializer(data=request.data)
			print('TYPE: ',type(request.data))
			print('REQ DATA: ',request.data)

			if serializer.is_valid():
				serializer.save()
				return Response(serializer.data,status=status.HTTP_201_CREATED)
			return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)
		except:
			print('R:',request.data)
			data = json.loads(request.data)
			print(data)
			return Response(serializer.data,status=status.HTTP_201_CREATED)

def api_post_sensorlight(request):

	if request.method == 'POST':
		try:
			serializer = LightSerializer(data=request.data)
			print('TYPE: ',type(request.data))
			print('REQ DATA: ',request.data)

			if serializer.is_valid():
				serializer.save()
				return Response(serializer.data,status=status.HTTP_201_CREATED)
			return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)
		except:
			print('R:',request.data)
			data = json.loads(request.data)
			print(data)
			return Response(serializer.data,status=status.HTTP_201_CREATED)

def home(request):
    return render(request,'dashboard/home.html')
    
def report(request):
    return render(request,'dashboard/report.html')