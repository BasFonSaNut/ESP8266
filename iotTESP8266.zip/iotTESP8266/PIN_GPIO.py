import network
from machine import Pin, ADC,SoftI2C
from i2c_lcd import I2cLcd
from lcd_api import LcdApi
import dht
import time
    
#ESP8266    




LDR = ADC(0) #AD LIGHT SENSOR
ldrled = Pin(16,Pin.OUT) #D0 ,LED AT LIGHT SENSOR
ldrled.on()

i2c = SoftI2C(scl=Pin(5),sda=Pin(4),freq=100000) #D1,#D2
lcd = I2cLcd(i2c, 0x27, 2, 16)
lcd.clear()
lcd.backlight_off()
lcd.display_off()

ledgreen = Pin(0, Pin.OUT) #D3
ledgreen.off()

ledyellow = Pin(2, Pin.OUT) #D4
ledyellow.off()

d = dht.DHT22(Pin(14)) #D5 TEMP SENSOR

ledred = Pin(12, Pin.OUT) #D6
ledred.off()


relayfan1 = Pin(13,Pin.OUT) #D7
relayfan1.on()

relay = Pin(15,Pin.OUT) #D8
relay.on()

relayfan2 = Pin(1,Pin.OUT) #TX
relayfan2.on()
