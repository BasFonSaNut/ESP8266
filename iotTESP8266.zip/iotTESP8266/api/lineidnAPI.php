<?php
class lineidnAPI
{
	function NotifyMessage($line_token,$message)
	{
		 try
		{
				$line_api = 'https://notify-api.line.me/api/notify';
				// ไปออก token กันเองตาม link บนแล้ว token มาใส่ข้างนะครับ
				$line_token = 'your token'; 
				
			   //ถ้าใครเอาสะดวก จะส่ง line ด้วย line api ไปเลยก็ได้นะครับผม
			   //ส่วนของผมจะสาย performance จะพยายามเขียนให้อยู่บน network layer ต่ำไว้ก่อน เลยใช้ curl
			   //คือไม่อยากไปตบตีแย่งชิง bandwidth กับเน็ตเวิร์คชั้น TCP/IP เขานะครับ
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL,$line_api);
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, 'message='.$message);
				// follow redirects
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
				curl_setopt($ch, CURLOPT_HTTPHEADER, [
					'Content-type: application/x-www-form-urlencoded',
					'Authorization: Bearer '.$line_token
				]);
				// receive server response ...
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

				$server_output = curl_exec ($ch);
				curl_close ($ch);
				
				$response = new stdClass();
				$response->Success = true;
				return $response;
		} catch (Exception $e) {
			$response = new stdClass();
			$response->Success = false;
			return $response;
		}
	}
}
?>