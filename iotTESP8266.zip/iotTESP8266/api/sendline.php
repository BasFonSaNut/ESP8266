<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
function dd_return($status, $message)
{
	$json = ['message' => $message];
    if($status)
    {
        http_response_code(200);
        die(json_encode($json));
    }
    else
    {
        http_response_code(400);
        die(json_encode($json));
    }
}

//////////////////////////////////////////////////////////////////////////

header('Content-Type: application/json; charset=utf-8;');

if ($_SERVER['REQUEST_METHOD'] == 'POST' &&  (isset($_POST['sendline']) && !empty($_POST['sendline'])))
{
			require_once 'lineidnAPI.php';
			$temp = $_POST['temp']; 
			$humid = $_POST['humid'];
			$line_api = 'https://notify-api.line.me/api/notify';
			$line_token = 'your token'; 
			$lineapi = new lineidnAPI();
			$message = '
			=============== TEMPERATURE NOTIFY==============
			สถานะอุณภูมิน่ากังวล
			[TEMPERATURE : '.$temp.'	  HUMID : '.$humid.'] 
			===============END DATA SENDING  ================';
			$response = $lineapi->NotifyMessage($line_token, $message);
			
			if($response->Success == true){	dd_return(true, "ทำรายการสำเร็จ");	}
			else	{	dd_return(false, "Method '{$_SERVER['REQUEST_METHOD']}' not allowed!");}
}
?>