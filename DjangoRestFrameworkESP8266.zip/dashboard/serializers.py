from rest_framework import serializers
from .models import *

class TempSerializer(serializers.ModelSerializer):
	class Meta:
		model = Temp
		fields = ('code','temp','humid')

class LightSerializer(serializers.ModelSerializer):
	class Meta:
		model = Light
		fields = ('code','min_l','max_l','avg_l')
