<?php
require_once '../api/config.php';

//ชื่อตาราง
$table = 'light';
//ชื่อคีย์หลัก
$primaryKey = 'id';

//ข้อมูลอะเรที่ส่งป datables
$columns = array(
	  array( 'db' => 'capture_dt', 'dt' => 0,
	  'formatter' => function($d, $row) {
		  $a  = date_create($d);
		  $cd = date_format($a,'d-m-Y');
          return $cd;
        }),
	 array( 'db' => 'capture_dti', 'dt' => 1),
	 array('db' => 'min_l','dt' => 2),
	 array( 'db' => 'max_l', 'dt' => 3),
	 array( 'db' => 'avg_l', 'dt' => 4)
);

	

//return "<a href='./customerv2/detail/".$d."' target='_blank' class='btn btn-primary'>ดูข้อมูล</a>";
  //เชื่อต่อฐานข้อมูล
  $sql_details = array(
    'user' => DB::$str_username,
    'pass' => DB::$str_password,
    'db'   => DB::$str_database,
    'host' => DB::$str_hosting
  );

  // เรียกใช้ไฟล์ spp.class.php
  require( 'ssp.class.php' );

  //ส่งข้อมูลกลับไปเป็น JSON
  if( (isset($_GET['dfl']) && !empty($_GET['dfl'])) && (isset($_GET['dtl'])==null || empty($_GET['dtl'])) )
  {
	  
    echo json_encode(
      SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, "order by capture_dt DESC", " capture_ts >= '".$_GET['dfl']."' ")
    );

  }
  else if( (isset($_GET['dtl']) && !empty($_GET['dtl'])) && (isset($_GET['dfl'])==null || empty($_GET['dfl'])) )
  {
	   
    echo json_encode(
       SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, "order by capture_dt DESC", " capture_ts <= '".$_GET['dtl']."' ")
    );
  }
 else if( (isset($_GET['dfl']) && !empty($_GET['dfl'])) && (isset($_GET['dtl']) && !empty($_GET['dtl'])) )
  {
    echo json_encode(
       SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, "order by capture_dt DESC", " capture_ts BETWEEN '".$_GET['dfl']."' AND '".$_GET['dtl']."' ")
    );
  }
   else if($_GET['dfl'] =="" && $_GET['dtl'] =="" )
  {
       echo json_encode(
      SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, "order by capture_dt DESC", " capture_ts = CURRENT_DATE() ")
    );
  }
  else
  {
    echo json_encode(
      SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, "order by capture_dt DESC", " capture_ts = CURRENT_DATE() ")
    );
  }
