function on_click(whichled)
   {
       urlx  = ''
          if(whichled == 'green')
          urlx = "http://192.168.1.83:89/?LED1=ON"
          if(whichled == 'red')
          urlx = "http://192.168.1.83:89/?LED2=ON"
          if(whichled == 'yellow')
          urlx = "http://192.168.1.83:89/?LED3=ON"
       $.ajax({
          type: 'GET',
          url: urlx,
          cache: false, 
          async: false, 
          contentType: "application/json; charset=utf-8", 
          processData: false,
          dataType: 'json' , 

          success: function (data) {
            console.log(data)
            console.log(JSON.stringify(data))
            console.log(data.LED)
            //alert(JSON.stringify(data))
              if(data.LED == 'LED1'){
                  $('#idimggreen').attr('src','http://192.168.1.52/media/lgon.png');
                  $('#led1txt').text('1:ON');
              }
              if(data.LED == 'LED2'){
                  $('#idimgred').attr('src','http://192.168.1.52/media/lron.png');
                  $('#led2txt').text('2:ON');
              }
              if(data.LED == 'LED3'){
                  $('#idimgyellow').attr('src','http://192.168.1.52/media/lyon.png');
                  $('#led3txt').text('3:ON');
              }
            },
            error: function (jqXhr, textStatus, errorMessage) {
                //do nothing
            }
        })
   }
   function off_click(whichled)
   {
       urlx  = ''
          if(whichled == 'green')
          urlx = "http://192.168.1.83:89/?LED1=OFF"
          if(whichled == 'red')
          urlx = "http://192.168.1.83:89/?LED2=OFF"
          if(whichled == 'yellow')
          urlx = "http://192.168.1.83:89/?LED3=OFF"
       $.ajax({
          type: 'GET',
          url: urlx,
          cache: false, 
          async: false, 
          contentType: "application/json; charset=utf-8", 
          processData: false,
          dataType: 'json' , 

          success: function (data) {
            console.log(data)
            console.log(JSON.stringify(data))
            console.log(data.LED)
            //alert(JSON.stringify(data))
              if(data.LED == 'LED1'){
                  $('#idimggreen').attr('src','http://192.168.1.52/media/loff.png');
                  $('#led1txt').text('1:OFF');
              }
              if(data.LED == 'LED2'){
                  $('#idimgred').attr('src','http://192.168.1.52/media/loff.png');
                  $('#led2txt').text('2:OFF');
              }
              if(data.LED == 'LED3'){
                  $('#idimgyellow').attr('src','http://192.168.1.52/media/loff.png');
                  $('#led3txt').text('3:OFF');
              }
            },
            error: function (jqXhr, textStatus, errorMessage) {
                //do nothing
            }
        })
   }

function rloc()
 {
       $.ajax({
          type: 'GET',
          url: "http://192.168.1.83:89/?RELAY=ON",
          cache: false, 
          async: false, 
          contentType: "application/json; charset=utf-8", 
          processData: false,
          dataType: 'json' , 

          success: function (data) {
            console.log(data)
            console.log(JSON.stringify(data))
            console.log(data.RELAY)
            //alert(JSON.stringify(data))
             
                  $('#imgrelaylight1').attr('src','http://192.168.1.52/media/lgon.png');
                  $('#relaylight1txt').text('1:ON');
             
                  $('#imgrelaylight2').attr('src','http://192.168.1.52/media/lron.png');
                  $('#relaylight2txt').text('2:ON');
             
                  $('#imgrelaylight3').attr('src','http://192.168.1.52/media/lyon.png');
                  $('#relaylight3txt').text('3:ON');
             
            },
            error: function (jqXhr, textStatus, errorMessage) {
                //do nothing
            }
        })
   }

function rlfc()
 {
       $.ajax({
          type: 'GET',
          url: "http://192.168.1.83:89/?RELAY=OFF",
          cache: false, 
          async: false, 
          contentType: "application/json; charset=utf-8", 
          processData: false,
          dataType: 'json' , 

          success: function (data) {
            console.log(data)
            console.log(JSON.stringify(data))
            console.log(data.RELAY)
            //alert(JSON.stringify(data))
             
                  $('#imgrelaylight1').attr('src','http://192.168.1.52/media/loff.png');
                  $('#relaylight1txt').text('1:OFF');
              
                  $('#imgrelaylight2').attr('src','http://192.168.1.52/media/loff.png');
                  $('#relaylight2txt').text('2:OFF');
            
                  $('#imgrelaylight3').attr('src','http://192.168.1.52/media/loff.png');
                  $('#relaylight3txt').text('3:OFF');
              
            },
            error: function (jqXhr, textStatus, errorMessage) {
                //do nothing
            }
        })
   }
function fmc(whichfan,whichlevel)
{
        if(whichfan == 1 && whichlevel >0)
            $('#idimgfan1').attr('src','http://192.168.1.52/media/fan-gif.gif');
        if(whichfan == 1 && whichlevel ==  0)
            $('#idimgfan1').attr('src','http://192.168.1.52/media/fanstop.png');
		if(whichfan == 2 && whichlevel >0)
            $('#idimgfan2').attr('src','http://192.168.1.52/media/fan-gif.gif');
        if(whichfan == 2 && whichlevel ==  0)
            $('#idimgfan2').attr('src','http://192.168.1.52/media/fanstop.png');

			if(whichfan == 1 && whichlevel == 0){
				$('#bigfan1').attr('src','http://192.168.1.52/media/bfst.png');
				$( document.body ).find(`[id^="statusiconfan1"]`).each(function(){
						  $( this ).attr("class","mx-auto center align-items-center");
				  });
			}
			if(whichfan == 1 && whichlevel == 1)
			{
				$('#bigfan1').attr('src','http://192.168.1.52/media/bfw.png');
				var a = setclassfan1icon($('#statusiconfan1lv1'));
			}
			if(whichfan == 1 && whichlevel == 2)
			{
				$('#bigfan1').attr('src','http://192.168.1.52/media/bfb.png');
				var a = setclassfan1icon($('#statusiconfan1lv2'));
			}
			if(whichfan == 1 && whichlevel == 3)
			{
				$('#bigfan1').attr('src','http://192.168.1.52/media/bflb.png');
				var a = setclassfan1icon($('#statusiconfan1lv3'));
			}
			
			if(whichfan == 1 && whichlevel == 4)
			{
				$('#bigfan1').attr('src','http://192.168.1.52/media/bfr.png');
				var a = setclassfan1icon($('#statusiconfan1lv4'));
			}

			

			if(whichfan == 2 && whichlevel == 0){
				$('#bigfan2').attr('src','http://192.168.1.52/media/bfst.png');
				$( document.body ).find(`[id^="statusiconfan2"]`).each(function(){
						  $( this ).attr("class","mx-auto center align-items-center");
				  });
			}
			if(whichfan == 2 && whichlevel == 1)
			{
				$('#bigfan2').attr('src','http://192.168.1.52/media/bfw.png');
				var a = setclassfan2icon($('#statusiconfan2lv1'));
			}
			if(whichfan == 2 && whichlevel == 2)
			{
				$('#bigfan2').attr('src','http://192.168.1.52/media/bfb.png');
				var a = setclassfan2icon($('#statusiconfan2lv2'));
			}
			if(whichfan == 2 && whichlevel == 3)
			{
				$('#bigfan2').attr('src','http://192.168.1.52/media/bflb.png');
				var a = setclassfan2icon($('#statusiconfan2lv3'));
			}
			
			if(whichfan == 2 && whichlevel == 4)
			{
				$('#bigfan2').attr('src','http://192.168.1.52/media/bfr.png');
				var a = setclassfan2icon($('#statusiconfan2lv4'));
			}

}
     
    //setInterval(myTimer, 3500); 
	//เอา commend บรรทัดบนออกเมื่อพร้อมรัน ไม่งั้นจะยิงไปขอค่าฝั่ง esp8266 ทุก 3500วิ จะหนักเกินไป
     
     function myTimer() {
        urlx = "http://192.168.1.83:89/?GETTEMPLIGHT";
        $.ajax({
          type: 'GET',
          url: urlx,
          cache: false, 
          async: false, 
          contentType: "application/json; charset=utf-8", 
          processData: false,
          dataType: 'json' , 

          success: function (data) {
                console.log(data);
                console.log(JSON.stringify(data));
                console.log(data.TEMP.TEMP);

				$("#degree").text(data.TEMP.TEMP);
                $("#degree").append("&deg;,&nbsp;&nbsp;");
                $("#degree").append(data.TEMP.HUMID);
                $("#degree").append("%");
				//onclick="setclassfan1icon($('#statusiconfan1lv2'));"

				if(data.TEMP.TEMP <= 28){
                    $('#bigtemp').attr('src','http://192.168.1.52/media/btst.png');
					$('#bigfan1').attr('src','http://192.168.1.52/media/bfst.png');
					$('#bigfan2').attr('src','http://192.168.1.52/media/bfst.png');
                }
                if(data.TEMP.TEMP > 28 && data.TEMP.TEMP <= 31){
                    $('#bigtemp').attr('src','http://192.168.1.52/media/btw.png');
					var a = setclasstempicon($('#statusicontemplv1'))

					$('#idimgfan1').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan1').attr('src','http://192.168.1.52/media/bfw.png');
					var a = setclassfan1icon($('#statusiconfan1lv1'))

					$('#idimgfan2').attr('src','http://192.168.1.52/media/fanstop.png');
                }
                if(data.TEMP.TEMP > 31 && data.TEMP.TEMP <= 34){
                   $('#bigtemp').attr('src','http://192.168.1.52/media/btb.png');
					var a = setclasstempicon($('#statusicontemplv2'))

					$('#idimgfan1').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan1').attr('src','http://192.168.1.52/media/bfb.png');
					var a = setclassfan1icon($('#statusiconfan1lv2'))
					$('#idimgfan2').attr('src','http://192.168.1.52/media/fanstop.png');
                }
				 if(data.TEMP.TEMP >34 && data.TEMP.TEMP <= 37){
                   $('#bigtemp').attr('src','http://192.168.1.52/media/btlb.png');
					var a = setclasstempicon($('#statusicontemplv3'))

					$('#idimgfan1').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan1').attr('src','http://192.168.1.52/media/bflb.png');
					var a = setclassfan1icon($('#statusiconfan1lv3'))
					$('#idimgfan2').attr('src','http://192.168.1.52/media/fanstop.png');
                }
				if(data.TEMP.TEMP >37 && data.TEMP.TEMP <=  40){
                    $('#bigtemp').attr('src','http://192.168.1.52/media/btr.png');
					var a = setclasstempicon($('#statusicontemplv4'))

					$('#idimgfan1').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan1').attr('src','http://192.168.1.52/media/bfr.png');
					var a = setclassfan1icon($('#statusiconfan1lv4'))
					$('#idimgfan2').attr('src','http://192.168.1.52/media/fanstop.png');
					sendline(data.TEMP.TEMP,data.TEMP.HUMID)
                }
				if(data.TEMP.TEMP >40 && data.TEMP.TEMP <= 43){
                    $('#bigtemp').attr('src','http://192.168.1.52/media/btr.png');
					var a = setclasstempicon($('#statusicontemplv4'))

					$('#idimgfan1').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan1').attr('src','http://192.168.1.52/media/bfr.png');
					var a = setclassfan1icon($('#statusiconfan1lv4'))

					$('#idimgfan2').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan2').attr('src','http://192.168.1.52/media/bfw.png');
					var a = setclassfan2icon($('#statusiconfan2lv1'))

					sendline(data.TEMP.TEMP,data.TEMP.HUMID)
                }
				if(data.TEMP.TEMP > 43 && data.TEMP.TEMP <= 47){
                   $('#bigtemp').attr('src','http://192.168.1.52/media/btr.png');
					var a = setclasstempicon($('#statusicontemplv4'))

					$('#idimgfan1').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan1').attr('src','http://192.168.1.52/media/bfr.png');
					var a = setclassfan1icon($('#statusiconfan1lv4'))

					$('#idimgfan2').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan2').attr('src','http://192.168.1.52/media/bfb.png');
					var a = setclassfan2icon($('#statusiconfan2lv2'))

					sendline(data.TEMP.TEMP,data.TEMP.HUMID)
                }
				if(data.TEMP.TEMP > 47 && data.TEMP.TEMP <=  50){
                   $('#bigtemp').attr('src','http://192.168.1.52/media/btr.png');
					var a = setclasstempicon($('#statusicontemplv4'))

					$('#idimgfan1').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan1').attr('src','http://192.168.1.52/media/bfr.png');
					var a = setclassfan1icon($('#statusiconfan1lv4'))

					$('#idimgfan2').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan2').attr('src','http://192.168.1.52/media/bflb.png');
					var a = setclassfan2icon($('#statusiconfan2lv3'))

					sendline()
                }
                
				if(data.TEMP.TEMP > 50 ){
                   $('#bigtemp').attr('src','http://192.168.1.52/media/btr.png');
					var a = setclasstempicon($('#statusicontemplv4'))

					$('#idimgfan1').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan1').attr('src','http://192.168.1.52/media/bfr.png');
					var a = setclassfan1icon($('#statusiconfan1lv4'))

					$('#idimgfan2').attr('src','http://192.168.1.52/media/fan-gif.gif');
					$('#bigfan2').attr('src','http://192.168.1.52/media/bfr.png');
					var a = setclassfan2icon($('#statusiconfan2lv4'))

					sendline(data.TEMP.TEMP,data.TEMP.HUMID)
                }

				if(data.TEMP.HUMID <= 50){
                    $('#bighumid').attr('src','http://192.168.1.52/media/bhw.png');
					var a = setclasshumidicon($('#statusiconhumidlv1'));
                }
				if(data.TEMP.HUMID > 50 && data.TEMP.HUMID <= 60){
                    $('#bighumid').attr('src','http://192.168.1.52/media/bhb.png');
					var a = setclasshumidicon($('#statusiconhumidlv2'));
                }

				 if(data.TEMP.HUMID > 60 && data.TEMP.HUMID <= 70){
                    $('#bighumid').attr('src','http://192.168.1.52/media/bhlb.png');
					var a = setclasshumidicon($('#statusiconhumidlv3'));
                }

                if(data.TEMP.HUMID > 70){
                    $('#bighumid').attr('src','http://192.168.1.52/media/bhr.png');
					var a = setclasshumidicon($('#statusiconhumidlv4'));
                }
               
                
				

				//=================== LIGHT===================
				$('#idluxtxt').text("LUX: ");
				$('#idluxtxt').append(data.LUX.MIN);

				if (data.LUX.MIN <= 500)
				{
						$('#imgrelaylight1').attr('src','http://192.168.1.52/media/loff.png');
						$('#relaylight1txt').text('1:OFF');
				  
					  $('#imgrelaylight2').attr('src','http://192.168.1.52/media/loff.png');
					  $('#relaylight2txt').text('2:OFF');
				
					  $('#imgrelaylight3').attr('src','http://192.168.1.52/media/loff.png');
					  $('#relaylight3txt').text('3:OFF');

					 $('#biglight').attr('src','http://192.168.1.52/media/blr.png');
					 var a = setclasslighticon($('#statusiconlightlv4'));
				}
				
				if (data.LUX.MIN > 500 && data.LUX.MIN <= 650)
				{
						$('#imgrelaylight1').attr('src','http://192.168.1.52/media/loff.png');
						$('#relaylight1txt').text('1:OFF');
				  
					  $('#imgrelaylight2').attr('src','http://192.168.1.52/media/loff.png');
					  $('#relaylight2txt').text('2:OFF');
				
					  $('#imgrelaylight3').attr('src','http://192.168.1.52/media/loff.png');
					  $('#relaylight3txt').text('3:OFF');

					 $('#biglight').attr('src','http://192.168.1.52/media/blb.png');
					 var a = setclasslighticon($('#statusiconlightlv2'));
				}
				
				if (data.LUX.MIN > 650 && data.LUX.MIN <= 799)
				{
						$('#imgrelaylight1').attr('src','http://192.168.1.52/media/loff.png');
						$('#relaylight1txt').text('1:OFF');
				  
					  $('#imgrelaylight2').attr('src','http://192.168.1.52/media/loff.png');
					  $('#relaylight2txt').text('2:OFF');
				
					  $('#imgrelaylight3').attr('src','http://192.168.1.52/media/loff.png');
					  $('#relaylight3txt').text('3:OFF');

					 $('#biglight').attr('src','http://192.168.1.52/media/bllb.png');
					 var a = setclasslighticon($('#statusiconlightlv3'));
				}

				if (data.LUX.MIN > 800)
				{
					 $('#imgrelaylight1').attr('src','http://192.168.1.52/media/lgon.png');
					  $('#relaylight1txt').text('1:ON');
				 
					  $('#imgrelaylight2').attr('src','http://192.168.1.52/media/lron.png');
					  $('#relaylight2txt').text('2:ON');
				 
					  $('#imgrelaylight3').attr('src','http://192.168.1.52/media/lyon.png');
					  $('#relaylight3txt').text('3:ON');
					  
					  $('#biglight').attr('src','http://192.168.1.52/media/blw.png');
					 var a = setclasslighticon($('#statusiconlightlv1'));
				}
	 
				//=================SAVE DATA==========
			var formData = new FormData();
			   formData.append('minx', data.LUX.MIN);
			   formData.append('maxx', 0);
			   formData.append('avgx', 0);
			   formData.append('temp', data.TEMP.TEMP);
			   formData.append('humid', data.TEMP.HUMID);
				$.ajax({
				type: 'POST',
				url: 'http://192.168.1.52/savedata',
				data:formData,
				contentType: false,
				processData: false,
			}).done(function(dataz){
						
					if(dataz[0].status == 200)
					{
						console.log('saved')
					}
					else if(dataz[0].status == 400)
					{
							console.log('error')
					}
					//console.clear();
				});	

            }
        })
    }

function sendline(tmp,hum)
{
			  var formData = new FormData();
			   formData.append('sendline', 1);
			   formData.append('temp', tmp);
			   formData.append('humid', hum);
				$.ajax({
				type: 'POST',
				url: 'http://192.168.1.52/sendline',
				data:formData,
				contentType: false,
				processData: false,
			}).done(function(dataz){
					console.log(dataz);
					if(dataz.status == 200)
					{
						console.log('send')
					}
					else if(dataz.status == 400)
					{
							console.log('error')
					}
					//console.clear();
				});	

}

$( document ).ready(function() 
 {
			 $( "img" ).each(function( i ) {
						$( this ).attr("class","mx-auto center align-items-center");
		  });

 });

function setclassfan1icon(obj)
{
	$( document.body ).find(`[id^="statusiconfan1"]`).each(function(){
		  $( this ).attr("class","mx-auto center align-items-center");
  });
	$(obj).attr("class","alerts-border shadow-sm mx-auto center align-items-center");
	return 1;
}

function setclassfan2icon(obj)
{
	$( document.body ).find(`[id^="statusiconfan2"]`).each(function(){
		  $( this ).attr("class","mx-auto center align-items-center");
  });
	$(obj).attr("class","alerts-border shadow-sm mx-auto center align-items-center");
	return 1;
}

function setclasshumidicon(obj)
{
	$( document.body ).find(`[id^="statusiconhumid"]`).each(function(){
		  $( this ).attr("class","mx-auto center align-items-center");
  });
	$(obj).attr("class","alerts-border shadow-sm mx-auto center align-items-center");
	return 1;
}

function setclasstempicon(obj)
{
	$( document.body ).find(`[id^="statusicontemp"]`).each(function(){
		  $( this ).attr("class","mx-auto center align-items-center");
  });
	$(obj).attr("class","alerts-border shadow-sm mx-auto center align-items-center");
	return 1;
}

function setclasslighticon(obj)
{
	$( document.body ).find(`[id^="statusiconlight"]`).each(function(){
		  $( this ).attr("class","mx-auto center align-items-center");
  });
	$(obj).attr("class","alerts-border shadow-sm mx-auto center align-items-center");
	return 1;
}
function linkreport()
{
	window.location.href ="http://192.168.1.52/esp8266report";
	
}
function linkdashboard()
{
	window.location.href="http://192.168.1.83:89";
}