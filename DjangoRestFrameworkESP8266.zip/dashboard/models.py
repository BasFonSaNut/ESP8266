from django.db import models
from django.utils import timezone
import datetime

# Create your models here.
class Temp(models.Model):
    # who order
    code = models.CharField(max_length=100,null=True, blank=True)
    temp = models.DecimalField(max_digits=4,decimal_places=2,null=True, blank=True, default=0.00)
    humid = models.DecimalField(max_digits=4,decimal_places=2,null=True, blank=True, default=0.00)
    capture_ts = models.DateTimeField(default=datetime.datetime.now())
 
    capture_da = models.DateField(default=timezone.now)
    #datetime.date.today()
    capture_dt = models.TimeField(default=timezone.now)
        
    def __self__(self):
        return self.id

class Light(models.Model):
    # who order
    code = models.CharField(max_length=100,null=True, blank=True)
    min_l = models.IntegerField(null=True, blank=True, default=0)
    max_l = models.IntegerField(null=True, blank=True, default=0)
    avg_l = models.IntegerField(null=True, blank=True, default=0)
    capture_ts = models.DateTimeField(default=datetime.datetime.now())
 
    capture_da = models.DateField(default=timezone.now)
    #datetime.date.today()
    capture_dt = models.TimeField(default=timezone.now)
    
    def __self__(self):
        return self.id