#ESP8266    
ledgreen = Pin(0, Pin.OUT) #D3
ledgreen.off()

ledred = Pin(12, Pin.OUT) #D6
ledred.off()

ledyellow = Pin(2, Pin.OUT) #D4
ledyellow.off()


i2c = SoftI2C(scl=Pin(5),sda=Pin(4),freq=100000) #D1,#D2
lcd = I2cLcd(i2c, 0x27, 2, 16)
lcd.clear()
lcd.backlight_off()
lcd.display_off()

d = dht.DHT22(Pin(14)) #D4

relay = Pin(15,Pin.OUT) #D8
relay.on()


relayfan1 = Pin(13,Pin.OUT) #D7
relayfan1.on()


relayfan2 = Pin(1,Pin.OUT) #TX
relayfan2.on()

LDR = ADC(0) #AD
ldrled = Pin(16,Pin.OUT) #D0
ldrled.on()