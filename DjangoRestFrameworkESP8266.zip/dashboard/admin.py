from django.contrib import admin
from .models import *
# Register your models here.

class Show_data(admin.ModelAdmin):
	list_display = ['id','code','temp','humid']
    
admin.site.register(Temp, Show_data)

class Show_data(admin.ModelAdmin):
	list_display = ['id','code','min_l','max_l','avg_l']
    
admin.site.register(Light, Show_data)
