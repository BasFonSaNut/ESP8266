<?php
require_once '../api/config.php';
$table = 'temper';
$primaryKey = 'id';
//ข้อมูลอะเรที่ส่งไป datables ที่หน้าแสดงผล HTML
$columns = array(
	  array( 'db' => 'capture_dt', 'dt' => 0,
	  'formatter' => function($d, $row) {
		  $a  = date_create($d);
		  $cd = date_format($a,'d-m-Y');
          return $cd;
        }
	  ),
	 array( 'db' => 'capture_dti', 'dt' => 1),
	 array('db' => 'temp','dt' => 2),
	 array( 'db' => 'humid', 'dt' => 3)
);

  //เชื่อต่อฐานข้อมูล
  $sql_details = array(
    'user' => DB::$str_username,
    'pass' => DB::$str_password,
    'db'   => DB::$str_database,
    'host' => DB::$str_hosting
  );

  // เรียกใช้ไฟล์ spp.class.php
  require( 'ssp.class.php' );

  //ส่งข้อมูลกลับไปเป็น JSON
  if( (isset($_GET['dft']) && !empty($_GET['dft'])) && (isset($_GET['dtt'])==null || empty($_GET['dtt'])) )
  {
    echo json_encode(
      SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, "order by capture_dt DESC", " capture_ts >= '".$_GET['dft']."' ")
    );
  }
  else if( (isset($_GET['dtt']) && !empty($_GET['dtt'])) && (isset($_GET['dft'])==null || empty($_GET['dft'])) )
  {
    echo json_encode(
       SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, "order by capture_dt DESC", " capture_ts <= '".$_GET['dft']."' ")
    );
  }
 else if( (isset($_GET['dft']) && !empty($_GET['dft'])) && (isset($_GET['dtt']) && !empty($_GET['dtt'])) )
  {
    echo json_encode(
       SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, "order by capture_dt DESC", " capture_ts BETWEEN '".$_GET['dft']."' AND '".$_GET['dtt']."' ")
    );
  }
  else
  {
    echo json_encode(
      SSP::complex( $_GET, $sql_details, $table, $primaryKey, $columns, "order by capture_dt DESC", " capture_ts = CURRENT_DATE() ")
    );
  }